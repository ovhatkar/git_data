import os

for index in range(1, 11):
    username = f"user{index}"
    print(f"creating user {username} ")
    
    # execute the create user system command
    os.system(f"useradd --comment {username} {username}")

    # change the password
    os.system(f'echo "{username}:test" | chpasswd')
    # os.system(f'echo test | passwd --stdin {username}')

