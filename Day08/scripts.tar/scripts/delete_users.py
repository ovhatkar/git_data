import os

for index in range(1, 11):
    username = f"user{index}"
    print(f"deleting user {username} ")
    
    # execute the delete user system command
    os.system(f"userdel -r {username}")

