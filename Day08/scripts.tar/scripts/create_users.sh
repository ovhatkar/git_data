echo "Creating 10 users"
for i in {1..10}
do
	# create a dynamic user name
	username="user$i"

	echo "creating user $username"

	# create a user using useradd command
	useradd --comment $username $username	

	# change the password for the user
	echo "$username:test" | chpasswd
	# echo test | passwd --stdin $username
done
