echo "Creating 10 users"
for i in {1..10}
do
	# create a dynamic user name
	username="user$i"

	echo "deleting user $username"

	# create a user using useradd command
	userdel -r $username	
done
